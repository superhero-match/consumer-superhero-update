create
    definer = root@localhost procedure delete_superhero(IN id varchar(255))
BEGIN

DELETE FROM superhero WHERE superhero.id = id;

END;

